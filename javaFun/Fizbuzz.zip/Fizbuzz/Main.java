
public class Main
{
	public static void main(String[] args) {
    FizzBuzz x= new FizzBuzz();
    String m=x.fizzBuzz(5);
    System.out.println(m);
	}
}
