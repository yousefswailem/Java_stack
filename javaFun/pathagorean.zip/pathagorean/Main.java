public class Main
{
	public static void main(String[] args) {
    Pythagorean x= new Pythagorean();
    double m=x.calculateHypotenuse(3,4);
    System.out.println(m);
	}
}
